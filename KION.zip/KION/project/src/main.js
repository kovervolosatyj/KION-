"use strict";
/* KION — «Ради тебя, любовь-нелюбовь».
   Браузерная версия: перенос main.py (pygame) на HTML5 Canvas.
   Зависит от levels.js (SIMPLE, Board, parseLevel, solve). */

(() => {
  const CONTINUE_URL = ""; // сюда можно вставить ссылку на продолжение новеллы
  const ASSET_DIR = "public/";
  const FONT_FAMILY = '"GRECHA", Georgia, serif';
  const LINE_RATIO = 1.1; // межстрочный коэффициент шрифта GRECHA (hhea: 750/-250/100)

  const HERO_START_TILES = {
    P: "tile_start_purple.png",
    R: "tile_start_(2).png",
    B: "tile_start_blue.png",
    Y: "tile_start_green.png",
  };
  const HERO_END_TILES = {
    P: "tile_end_purple.png",
    R: "tile_end_(2).png",
    B: "tile_end_blue.png",
    Y: "tile_end_green.png",
  };
  const ITEM_IMAGES = { mirror: "mirror.png", horse: "horse.png", apple: "apple.png" };
  const POPUP_IMAGE = "textblock.png";
  const BACKGROUND_DESKTOP = "background_desktop.png";
  const BACKGROUND_PORTRAIT = "background.png";
  const SPLASH_IMAGE = "kion_desktop.png";
  const MUSIC_FILE = "Circassian Breeze.mp3";

  const IMAGE_FILES = [
    BACKGROUND_DESKTOP, BACKGROUND_PORTRAIT, POPUP_IMAGE,
    "tile1.png", "tile2.png", "tile_start.png", "tile_end.png",
    ...Object.values(HERO_START_TILES), ...Object.values(HERO_END_TILES),
    ...Object.values(ITEM_IMAGES),
  ];

  const BG = [12, 12, 15];
  const TILE = [40, 40, 47];
  const TILE_EDGE = [92, 92, 104];
  const CREAM = [241, 236, 226];
  const INK = [14, 14, 16];
  const HERO_COL = {
    P: [139, 92, 255],
    R: [220, 55, 65],
    B: [79, 198, 235],
    Y: [104, 211, 142],
  };

  const INTRO = "Амипат, юная красавица, когда-то полюбила сразу троих друзей, а они — ее. " +
    "И решили они положить конец сомнениям, назначив ей встречу…";

  const START_STORY = {
    0: [INTRO,
      "Амипат спешит к друзьям. Проведи девушку через улочки аула: проложи её путь " +
      "непрерывной тропой, не пропустив ни одного закоулка."],
    1: ["Друзья отправились на рынок за подарками для Амипат: кто принесет лучший, тому она и достанется.",
      "Всяк из трех молодцев присмотрел для Амипат особенный подарок. Да только каждому под силу " +
      "унести лишь один — и чужой ему не годится!",
      "Помоги друзьям обойти рынок: проведи каждого через ярмарку своим путем и не забудь прихватить подарки."],
    2: ["Встретились друзья, заглянули в зеркало и увидели, что Амипат умирает.",
      "Приведи молодцев обратно к возлюбленной!"],
    3: ["Спешили друзья к Амипат, да знали, что не каждого она выберет."],
  };
  const ITEM_TEXT = {
    B: "Зеркало, в котором всегда видно любимую.",
    P: "Конь, который быстрее ветра домчит до любимой.",
    R: "Яблоко, которое может дарить жизнь.",
  };
  const END_STORY = [
    "Откусив яблоко, Амипат ожила. Мудрец в ауле рассудил, что она должна достаться тому, кто принес яблоко. " +
    "Так и вышло.",
    "Спустя время совместной жизни муж Амипат вдруг умирает при странных обстоятельствах. От горя она " +
    "отправляется искать способ вернуть любимого на тот же рынок, где было куплено яблоко.",
    "У одной старухи находится то, что нужно Амипат: дудочка, способная воскресить мертвеца. " +
    "Амипат спрашивает цену, но деньги старуху не интересуют…",
  ];
  const FINAL_TITLE = "Продолжение следует…";
  const FINAL_BUTTON = "ЧИТАТЬ ПРОДОЛЖЕНИЕ";
  const LEVEL_TITLES = ["Обучение", "Уровень 1", "Уровень 2", "Уровень 3", "Уровень 4"];
  const DEMO_LEVELS = [0, 1];

  /* ---------- утилиты ---------- */

  const rgb = (c, a = 1) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;
  const mix = (a, b, t) => [0, 1, 2].map((i) => Math.trunc(a[i] + (b[i] - a[i]) * t));
  const ease = (t) => { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); };

  function roundRectPath(c, x, y, w, h, r) {
    r = Math.max(0, Math.min(r, w / 2, h / 2));
    c.beginPath();
    c.moveTo(x + r, y);
    c.arcTo(x + w, y, x + w, y + h, r);
    c.arcTo(x + w, y + h, x, y + h, r);
    c.arcTo(x, y + h, x, y, r);
    c.arcTo(x, y, x + w, y, r);
    c.closePath();
  }

  /* ---------- холст и ресурсы ---------- */

  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");
  let W = 0, H = 0, DPR = 1;
  let game = null;

  const images = {};
  const scaledCache = new Map();
  let bgCache = null;
  let layer = null; // служебная поверхность для полупрозрачной подсказки

  function makeSurface() {
    const cv = document.createElement("canvas");
    cv.width = Math.max(1, Math.round(W * DPR));
    cv.height = Math.max(1, Math.round(H * DPR));
    const c = cv.getContext("2d");
    c.setTransform(DPR, 0, 0, DPR, 0, 0);
    return { cv, c };
  }

  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth;
    H = window.innerHeight;
    canvas.width = Math.max(1, Math.round(W * DPR));
    canvas.height = Math.max(1, Math.round(H * DPR));
    canvas.style.width = W + "px";
    canvas.style.height = H + "px";
    scaledCache.clear();
    bgCache = null;
    layer = null;
  }

  function loadImage(name) {
    return new Promise((resolve) => {
      const im = new Image();
      im.onload = () => { images[name] = im; resolve(im); };
      im.onerror = () => { images[name] = null; resolve(null); };
      im.src = ASSET_DIR + encodeURI(name);
    });
  }

  /** Картинка, заранее уменьшенная до нужного размера (в CSS-пикселях). */
  function asset(name, w, h) {
    const im = images[name];
    if (!im) return null;
    const pw = Math.max(1, Math.round(w * DPR));
    const ph = Math.max(1, Math.round(h * DPR));
    const key = `${name}|${pw}x${ph}`;
    let cv = scaledCache.get(key);
    if (!cv) {
      cv = document.createElement("canvas");
      cv.width = pw;
      cv.height = ph;
      const x = cv.getContext("2d");
      x.imageSmoothingQuality = "high";
      x.drawImage(im, 0, 0, pw, ph);
      scaledCache.set(key, cv);
    }
    return cv;
  }

  function drawAsset(c, name, x, y, w, h) {
    const cv = asset(name, w, h);
    if (!cv) return false;
    c.drawImage(cv, x, y, w, h);
    return true;
  }

  /** Фон «cover»: заполняет экран с обрезкой по центру. */
  function drawCoverBackground(c, name) {
    const im = images[name];
    if (!im) return false;
    const key = `${name}|${W}|${H}|${DPR}`;
    if (!bgCache || bgCache.key !== key) {
      const pw = Math.max(1, Math.round(W * DPR));
      const ph = Math.max(1, Math.round(H * DPR));
      const cv = document.createElement("canvas");
      cv.width = pw;
      cv.height = ph;
      const x = cv.getContext("2d");
      x.imageSmoothingQuality = "high";
      const s = Math.max(pw / im.naturalWidth, ph / im.naturalHeight);
      const nw = im.naturalWidth * s, nh = im.naturalHeight * s;
      x.drawImage(im, (pw - nw) / 2, (ph - nh) / 2, nw, nh);
      bgCache = { key, cv };
    }
    c.drawImage(bgCache.cv, 0, 0, W, H);
    return true;
  }

  /* ---------- текст ---------- */

  function setFont(c, size, bold) {
    c.font = `${bold ? "bold " : ""}${Math.max(1, Math.round(size))}px ${FONT_FAMILY}`;
  }

  function measure(c, text, spacing = 1) {
    const chars = [...text];
    let w = 0;
    for (const ch of chars) w += c.measureText(ch).width;
    return w + spacing * Math.max(0, chars.length - 1);
  }

  /** Рисует текст с межбуквенным интервалом, как draw_text в pygame-версии.
      anchor: "center" | "left" (x — центр или левый край, y — центр строки). */
  function drawText(c, text, size, bold, color, x, y, anchor = "center", spacing = 1) {
    setFont(c, size, bold);
    c.fillStyle = color;
    c.textBaseline = "middle";
    c.textAlign = "left";
    const chars = [...text];
    const widths = chars.map((ch) => c.measureText(ch).width);
    const total = widths.reduce((a, b) => a + b, 0) + spacing * Math.max(0, chars.length - 1);
    let cx = anchor === "center" ? x - total / 2 : x;
    const left = cx;
    chars.forEach((ch, i) => {
      c.fillText(ch, cx, y);
      cx += widths[i] + spacing;
    });
    const h = Math.round(size * LINE_RATIO);
    return { x: left, y: y - h / 2, w: total, h };
  }

  function wrapText(c, text, size, maxW) {
    setFont(c, size, false);
    const lines = [];
    let cur = "";
    for (const word of text.split(/\s+/).filter(Boolean)) {
      const test = (cur + " " + word).trim();
      if (measure(c, test) <= maxW || !cur) {
        cur = test;
      } else {
        lines.push(cur);
        cur = word;
      }
    }
    if (cur) lines.push(cur);
    return lines;
  }

  /* ---------- игра ---------- */

  class Game {
    constructor() {
      this.levelIdx = 0;
      this.seenStart = new Set();
      this.shownItems = new Set();
      this.popups = [];
      this.popupT = 0;
      this.then = null;
      this.trans = null;
      this.final = false;
      this.winTimer = null;
      this.toast = ["", 0];
      this.demoT = 0;
      this.lastPos = null;
      this.ui = {};
      this.solutions = new Map();
      this.loadLevel(0);
      this.startStory(0);
    }

    loadLevel(idx) {
      this.levelIdx = idx;
      this.level = parseLevel(SIMPLE[idx]);
      this.board = new Board(this.level);
      this.winTimer = null;
      this.demoT = 0;
      // решение нужно только для демонстрации пути на первых уровнях
      if (DEMO_LEVELS.includes(idx)) {
        if (!this.solutions.has(idx)) this.solutions.set(idx, solve(this.level));
        this.solution = this.solutions.get(idx);
      } else {
        this.solution = null;
      }
    }

    restart() {
      this.board.reset();
      this.winTimer = null;
      this.demoT = 0;
    }

    startStory(idx) {
      if (idx in START_STORY && !this.seenStart.has(idx)) {
        this.seenStart.add(idx);
        this.show(START_STORY[idx]);
      }
    }

    show(texts, then = null) {
      this.popups = [...texts];
      this.popupT = 0;
      this.then = then;
    }

    closePopup() {
      if (!this.popups.length) return;
      this.popups.shift();
      this.popupT = 0;
      if (!this.popups.length && this.then) {
        const cb = this.then;
        this.then = null;
        cb();
      }
    }

    levelComplete() {
      if (this.levelIdx === SIMPLE.length - 1) {
        this.show(END_STORY, () => { this.final = true; });
        return;
      }
      const old = makeSurface();
      this.drawScene(old.c);
      this.loadLevel(this.levelIdx + 1);
      const nw = makeSurface();
      this.drawScene(nw.c);
      this.trans = { old: old.cv, nw: nw.cv, t: 0 };
    }

    /* --- ввод --- */

    onKey(e) {
      if ((e.code === "Space" || e.code === "Enter") && this.popups.length && this.popupT > 0.15) {
        this.closePopup();
        e.preventDefault();
      } else if (e.code === "KeyR" && !this.popups.length && !this.trans) {
        this.restart();
      }
    }

    onPress(x, y) {
      if (this.final) {
        const r = this.ui.final;
        if (r && x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) {
          if (CONTINUE_URL) window.open(CONTINUE_URL, "_blank", "noopener");
          else this.toast = ["Здесь будет ссылка на продолжение новеллы", 3.0];
        }
        return;
      }
      if (this.popups.length) {
        if (this.popupT > 0.15) this.closePopup();
        return;
      }
      if (this.trans || this.winTimer !== null) return;
      const r = this.ui.restart;
      if (r && x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) {
        this.restart();
        return;
      }
      const cell = this.cellAt(x, y);
      if (cell !== null && this.board.press(cell)) this.lastPos = [x, y];
    }

    onMove(x, y) {
      if (this.popups.length || this.trans || this.winTimer !== null || this.board.active === null) return;
      const g = this.geom();
      const a = this.lastPos || [x, y];
      const dist = Math.hypot(x - a[0], y - a[1]);
      const n = Math.max(1, Math.trunc(dist / (g.pitch * 0.25)));
      // «досчитываем» клетки при быстром движении пальца
      for (let i = 1; i <= n; i++) {
        const px = a[0] + (x - a[0]) * i / n;
        const py = a[1] + (y - a[1]) * i / n;
        const cell = this.cellAt(px, py);
        if (cell !== null) this.apply(this.board.step(cell));
      }
      this.lastPos = [x, y];
    }

    onRelease() {
      this.board.release();
      this.lastPos = null;
    }

    apply(events) {
      for (const [ev, hid] of events) {
        if (ev === "done" && this.board.itemCollected(hid)) {
          const key = `${this.levelIdx}:${hid}`;
          if (!this.shownItems.has(key) && hid in ITEM_TEXT) {
            this.shownItems.add(key);
            this.show([ITEM_TEXT[hid]]);
          }
        } else if (ev === "win") {
          this.winTimer = 0.7;
        }
      }
    }

    /* --- обновление --- */

    update(dt) {
      if (this.popups.length) this.popupT += dt;
      if (this.toast[1] > 0) this.toast = [this.toast[0], this.toast[1] - dt];
      if (this.trans) {
        this.trans.t += dt / 0.9;
        if (this.trans.t >= 1) {
          this.trans = null;
          this.startStory(this.levelIdx);
        }
        return;
      }
      if (this.winTimer !== null && !this.popups.length) {
        this.winTimer -= dt;
        if (this.winTimer <= 0) {
          this.winTimer = null;
          this.levelComplete();
        }
      }
      this.demoT = this.demoActive() ? this.demoT + dt : 0;
    }

    demoActive() {
      return DEMO_LEVELS.includes(this.levelIdx) && !!this.solution && !this.popups.length &&
        !this.trans && !this.final && !this.board.started && this.winTimer === null;
    }

    /* --- геометрия --- */

    unit() {
      return Math.max(0.7, Math.min(W / 480, H / 800));
    }

    geom() {
      const u = this.unit();
      const hud = Math.trunc(104 * u);
      const pad = Math.trunc(18 * u);
      const pitch = Math.min(
        (W - 2 * pad) / this.level.cols,
        (H - hud - 2 * pad) / this.level.rows,
        150 * u,
      );
      const bw = pitch * this.level.cols, bh = pitch * this.level.rows;
      return { pitch, ox: (W - bw) / 2, oy: hud + (H - hud - bh) / 2 };
    }

    center(g, cell) {
      return [g.ox + (cellCol(cell) + 0.5) * g.pitch, g.oy + (cellRow(cell) + 0.5) * g.pitch];
    }

    cellAt(x, y) {
      const g = this.geom();
      const c = (x - g.ox) / g.pitch, r = (y - g.oy) / g.pitch;
      const ci = Math.floor(c), ri = Math.floor(r);
      if (ci < 0 || ci >= K || !this.level.tiles.has(cellId(ri, ci))) return null;
      if (Math.max(Math.abs(c - ci - 0.5), Math.abs(r - ri - 0.5)) > 0.46) return null;
      return cellId(ri, ci);
    }

    /* --- отрисовка --- */

    draw(c) {
      if (this.trans) {
        const e = ease(this.trans.t);
        c.fillStyle = rgb(BG);
        c.fillRect(0, 0, W, H);
        c.drawImage(this.trans.old, 0, -H * e, W, H);
        c.drawImage(this.trans.nw, 0, H - H * e, W, H);
        return;
      }
      this.drawScene(c);
      const u = this.unit();
      if (this.final) this.drawFinal(c, u);
      else if (this.popups.length) this.drawPopup(c, u);
      if (this.toast[1] > 0) {
        const r = drawText(c, this.toast[0], 16 * u, false, rgb(CREAM), W / 2, H - 40 * u);
        c.strokeStyle = rgb(CREAM);
        c.lineWidth = 1;
        roundRectPath(c, r.x - 12 + 0.5, r.y - 7 + 0.5, r.w + 24, r.h + 14, 10);
        c.stroke();
      }
    }

    drawScene(c) {
      const u = this.unit();
      const bgName = H > W ? BACKGROUND_PORTRAIT : BACKGROUND_DESKTOP;
      let hasBg = drawCoverBackground(c, bgName);
      if (!hasBg && bgName !== BACKGROUND_DESKTOP) hasBg = drawCoverBackground(c, BACKGROUND_DESKTOP);
      if (hasBg) {
        c.fillStyle = "rgba(0,0,0," + (112 / 255) + ")";
        c.fillRect(0, 0, W, H);
      } else {
        c.fillStyle = rgb(BG);
        c.fillRect(0, 0, W, H);
      }

      // декоративная «ограда» внизу экрана
      const barH = Math.trunc(H * 0.035);
      c.fillStyle = "rgb(30,30,36)";
      let x = 0, i = 0;
      while (x < W) {
        const bw = Math.trunc(5 * u) + ((i * 7) % 4) * Math.trunc(2 * u);
        c.fillRect(x, H - barH, bw, barH);
        x += bw + Math.trunc(9 * u);
        i++;
      }
      this.drawHud(c, u);
      this.drawBoard(c, this.geom(), u);
    }

    drawHud(c, u) {
      const pad = Math.trunc(18 * u);
      drawText(c, LEVEL_TITLES[this.levelIdx], 28 * u, true, rgb(CREAM), pad, Math.trunc(32 * u), "left");

      const ids = this.levelIdx === 0 ? ["Y"] : ["P", "R", "B"];
      const present = new Set(this.level.heroes.map((h) => h.id));
      const rad = Math.trunc(9 * u);
      let x = W - pad - Math.trunc(52 * u) - ids.length * Math.trunc(26 * u);
      for (const hid of ids) {
        const cy = Math.trunc(32 * u);
        c.beginPath();
        c.arc(x, cy, rad, 0, Math.PI * 2);
        if (present.has(hid)) {
          c.fillStyle = rgb(HERO_COL[hid]);
          c.fill();
        } else {
          c.strokeStyle = rgb(mix(HERO_COL[hid], BG, 0.7));
          c.lineWidth = 2;
          c.stroke();
        }
        x += Math.trunc(26 * u);
      }

      // кнопка «заново»
      const sz = Math.trunc(40 * u);
      const cx = W - pad - Math.trunc(20 * u), cy = Math.trunc(32 * u);
      const r = { x: cx - sz / 2, y: cy - sz / 2, w: sz, h: sz };
      c.strokeStyle = rgb(CREAM);
      c.lineWidth = 2;
      roundRectPath(c, r.x, r.y, r.w, r.h, Math.trunc(12 * u));
      c.stroke();
      const rr = Math.trunc(8 * u);
      c.beginPath();
      c.arc(cx, cy, rr, -5.8, -0.7, false); // дуга 0.7…5.8 рад (против часовой на экране)
      c.stroke();
      const ax = cx + Math.cos(0.7) * rr, ay = cy - Math.sin(0.7) * rr;
      c.fillStyle = rgb(CREAM);
      c.beginPath();
      c.moveTo(ax - 5 * u, ay - 4 * u);
      c.lineTo(ax + 5 * u, ay - 4 * u);
      c.lineTo(ax + 1 * u, ay + 5 * u);
      c.closePath();
      c.fill();
      this.ui.restart = r;

      // собранные подарки (уровень 1)
      if (this.levelIdx === 1) {
        const thumb = Math.max(18, Math.trunc(27 * u));
        let tx = pad;
        const ty = Math.trunc(66 * u);
        for (const hid of ["P", "R", "B"]) {
          if (!(hid in this.board.hero) || !this.board.itemCollected(hid)) continue;
          const kind = this.board.hero[hid].itemKind;
          c.fillStyle = "rgb(20,20,25)";
          roundRectPath(c, tx, ty, thumb, thumb, Math.max(3, Math.trunc(5 * u)));
          c.fill();
          drawAsset(c, ITEM_IMAGES[kind] || "", tx, ty, thumb, thumb);
          c.strokeStyle = rgb(HERO_COL[hid]);
          c.lineWidth = Math.max(1, Math.trunc(2 * u));
          roundRectPath(c, tx, ty, thumb, thumb, Math.max(3, Math.trunc(5 * u)));
          c.stroke();
          tx += thumb + Math.trunc(7 * u);
        }
      }
    }

    drawBoard(c, g, u) {
      const lv = this.level, bd = this.board;
      const pitch = g.pitch;
      const size = Math.trunc(pitch * 0.88);
      const rad = Math.trunc(pitch * 0.18);
      const occ = new Map();
      for (const hid in bd.paths) for (const cell of bd.paths[hid]) occ.set(cell, hid);
      const starts = new Map(lv.heroes.map((h) => [h.start, h]));
      const ends = new Map(lv.heroes.map((h) => [h.end, h]));

      for (const cell of lv.tiles) {
        const [cx, cy] = this.center(g, cell);
        const rx = Math.trunc(cx - size / 2), ry = Math.trunc(cy - size / 2);
        const hid = occ.get(cell);
        if (starts.has(cell)) {
          const hero = starts.get(cell);
          const name = this.levelIdx === 0 ? "tile_start_green.png" : (HERO_START_TILES[hero.id] || "tile_start_green.png");
          if (!drawAsset(c, name, rx, ry, size, size)) drawAsset(c, "tile_start.png", rx, ry, size, size);
        } else if (ends.has(cell)) {
          const hero = ends.get(cell);
          const name = this.levelIdx === 0 ? "tile_end_green.png" : (HERO_END_TILES[hero.id] || "tile_end.png");
          if (!drawAsset(c, name, rx, ry, size, size)) drawAsset(c, "tile_end.png", rx, ry, size, size);
        } else {
          const name = (cellRow(cell) + cellCol(cell)) % 2 ? "tile1.png" : "tile2.png";
          if (!drawAsset(c, name, rx, ry, size, size)) {
            c.fillStyle = rgb(TILE);
            roundRectPath(c, rx, ry, size, size, rad);
            c.fill();
            c.strokeStyle = rgb(TILE_EDGE);
            c.lineWidth = 2;
            c.stroke();
          }
          if (hid) {
            // мягкая подсветка клетки цветом героя
            const pad = Math.max(2, Math.trunc(pitch * 0.005));
            c.save();
            c.shadowColor = rgb(HERO_COL[hid], 0.3);
            c.shadowBlur = Math.max(2, pitch * 0.05);
            c.fillStyle = rgb(HERO_COL[hid], 65 / 255);
            roundRectPath(c, rx - pad / 2, ry - pad / 2, size + pad, size + pad, rad);
            c.fill();
            c.restore();
          }
        }
      }

      for (const h of lv.heroes) {
        const pts = bd.paths[h.id].map((cell) => this.center(g, cell));
        this.drawTrail(c, pts, HERO_COL[h.id], pitch);
        if (pts.length && (bd.active === h.id || pts.length > 1)) {
          const [hx, hy] = pts[pts.length - 1];
          const lw = Math.max(3, Math.trunc(pitch * 0.17));
          c.fillStyle = rgb(CREAM);
          c.beginPath();
          c.arc(hx, hy, Math.trunc(lw * 0.78), 0, Math.PI * 2);
          c.fill();
          c.fillStyle = rgb(mix(HERO_COL[h.id], INK, 0.62));
          c.beginPath();
          c.arc(hx, hy, Math.trunc(lw * 0.57), 0, Math.PI * 2);
          c.fill();
        }
      }

      for (const [cell, [hid, kind]] of lv.items) {
        const [cx, cy] = this.center(g, cell);
        const col = HERO_COL[hid];
        const got = bd.itemCollected(hid);
        const d = pitch * 0.34;
        c.beginPath();
        c.moveTo(cx, cy - d);
        c.lineTo(cx + d, cy);
        c.lineTo(cx, cy + d);
        c.lineTo(cx - d, cy);
        c.closePath();
        c.fillStyle = rgb(got ? col : INK);
        c.fill();
        c.strokeStyle = rgb(got ? CREAM : col);
        c.lineWidth = Math.max(2, Math.trunc(pitch * 0.045));
        c.lineJoin = "miter";
        c.stroke();
        const icon = Math.max(8, Math.trunc(pitch * 0.48));
        drawAsset(c, ITEM_IMAGES[kind] || "", Math.trunc(cx - icon / 2), Math.trunc(cy - icon / 2), icon, icon);
      }

      if (this.demoActive()) this.drawDemo(c, g, u);
    }

    drawTrail(c, pts, heroColor, pitch) {
      if (pts.length < 2) return;
      const width = Math.max(3, Math.trunc(pitch * 0.17));
      const outline = width + Math.max(2, Math.trunc(pitch * 0.045));
      c.save();
      c.lineJoin = "round";
      c.lineCap = "round";
      c.strokeStyle = rgb(CREAM);
      c.lineWidth = outline;
      c.beginPath();
      c.moveTo(pts[0][0], pts[0][1]);
      for (let i = 1; i < pts.length; i++) c.lineTo(pts[i][0], pts[i][1]);
      c.stroke();

      const segments = pts.length - 1;
      for (let i = 0; i < segments; i++) {
        const t = (i + 1) / Math.max(1, segments);
        const col = rgb(mix(heroColor, INK, 0.48 + 0.42 * t));
        c.strokeStyle = col;
        c.fillStyle = col;
        c.lineWidth = width;
        c.beginPath();
        c.moveTo(pts[i][0], pts[i][1]);
        c.lineTo(pts[i + 1][0], pts[i + 1][1]);
        c.stroke();
        c.beginPath();
        c.arc(pts[i + 1][0], pts[i + 1][1], width / 2, 0, Math.PI * 2);
        c.fill();
      }
      c.restore();
    }

    /** Подсказка: путь первого героя рисуется сам и плавно гаснет. */
    drawDemo(c, g, u) {
      const hid = this.level.heroes[0].id;
      const path = this.solution[hid];
      const pts = path.map((cell) => this.center(g, cell));
      const perTile = 0.16, hold = 1.3, fade = 0.5, pause = 2.0;
      const drawT = perTile * (pts.length - 1);
      const t = this.demoT % (drawT + hold + fade + pause);
      let f, alpha;
      if (t < drawT) { f = t / perTile; alpha = 255; }
      else if (t < drawT + hold) { f = pts.length - 1; alpha = 255; }
      else if (t < drawT + hold + fade) { f = pts.length - 1; alpha = Math.trunc(255 * (1 - (t - drawT - hold) / fade)); }
      else return;
      const i = Math.min(Math.trunc(f), pts.length - 2);
      const k = f - i;
      const cur = [
        pts[i][0] + (pts[i + 1][0] - pts[i][0]) * k,
        pts[i][1] + (pts[i + 1][1] - pts[i][1]) * k,
      ];
      const line = pts.slice(0, i + 1).concat([cur]);

      if (!layer) layer = makeSurface();
      layer.c.clearRect(0, 0, W, H);
      this.drawTrail(layer.c, line, HERO_COL[hid], g.pitch);
      c.save();
      c.globalAlpha = alpha / 255;
      c.drawImage(layer.cv, 0, 0, W, H);
      c.restore();

      if (t < drawT + hold) {
        const r = Math.trunc(g.pitch * 0.26);
        c.fillStyle = "rgba(255,255,255," + (190 / 255) + ")";
        c.beginPath();
        c.arc(cur[0], cur[1], r, 0, Math.PI * 2);
        c.fill();
        c.strokeStyle = "rgb(255,255,255)";
        c.lineWidth = 3;
        c.beginPath();
        c.arc(cur[0], cur[1], Math.trunc(r * 1.6), 0, Math.PI * 2);
        c.stroke();
      }
    }

    drawPopup(c, u) {
      c.fillStyle = "rgba(0,0,0," + (150 / 255) + ")";
      c.fillRect(0, 0, W, H);

      const text = this.popups[0];
      const pw = Math.min(Math.trunc(W * 0.92), Math.trunc(620 * u));
      const ph = Math.min(Math.trunc(H * 0.60), Math.trunc(390 * u));
      const e = ease(this.popupT / 0.25);
      const px = Math.trunc((W - pw) / 2);
      const py = Math.trunc((H - ph) / 2) - Math.trunc(20 * u * (1 - e));

      c.save();
      c.globalAlpha = e;
      if (!drawAsset(c, POPUP_IMAGE, px, py, pw, ph)) {
        c.fillStyle = "rgb(32,30,37)";
        roundRectPath(c, px, py, pw, ph, Math.trunc(18 * u));
        c.fill();
        c.strokeStyle = rgb(CREAM);
        c.lineWidth = Math.max(1, Math.trunc(2 * u));
        roundRectPath(c, px + 6, py + 6, pw - 12, ph - 12, Math.trunc(14 * u));
        c.stroke();
      }

      const padX = Math.trunc(pw * 0.13);
      const textTop = Math.trunc(ph * 0.16);
      const textBottom = Math.trunc(ph * 0.22);
      const availH = ph - textTop - textBottom;
      const availW = pw - padX * 2;
      const gap = Math.max(2, Math.trunc(3 * u));

      // подбираем размер шрифта так, чтобы текст поместился
      let size = Math.max(12, Math.trunc(18 * u));
      while (size > 11) {
        const n = wrapText(c, text, size, availW).length;
        if (Math.round(size * LINE_RATIO) + gap > 0 && (Math.round(size * LINE_RATIO) + gap) * n <= availH) break;
        size--;
      }
      const lines = wrapText(c, text, size, availW);
      const lineH = Math.round(size * LINE_RATIO) + gap;
      let y = py + textTop + Math.trunc((availH - lineH * lines.length) / 2);
      for (const line of lines) {
        drawText(c, line, size, false, "rgb(255,255,255)", px + pw / 2, y + Math.trunc(lineH / 2));
        y += lineH;
      }
      drawText(c, "нажмите, чтобы продолжить", Math.max(15, 12 * u), false, "rgb(255,255,255)",
        px + pw / 2, py + ph - Math.trunc(120 * u));
      c.restore();
    }

    drawFinal(c, u) {
      c.fillStyle = "rgba(0,0,0," + (200 / 255) + ")";
      c.fillRect(0, 0, W, H);
      drawText(c, FINAL_TITLE, 30 * u, true, rgb(CREAM), W / 2, H / 2 - Math.trunc(70 * u));
      const w = Math.min(Math.trunc(W * 0.84), Math.trunc(420 * u));
      const h = Math.trunc(64 * u);
      const r = { x: Math.trunc(W / 2 - w / 2), y: Math.trunc(H / 2 + 10 * u - h / 2), w, h };
      c.fillStyle = rgb(CREAM);
      roundRectPath(c, r.x, r.y, r.w, r.h, Math.trunc(14 * u));
      c.fill();
      drawText(c, FINAL_BUTTON, 20 * u, true, rgb(INK), r.x + r.w / 2, r.y + r.h / 2);
      this.ui.final = r;
    }
  }

  /* ---------- звук ---------- */

  const music = new Audio(ASSET_DIR + encodeURI(MUSIC_FILE));
  music.loop = true;
  music.volume = 0.3;
  let musicStarted = false;

  function tryPlayMusic() {
    if (musicStarted) return;
    const p = music.play();
    if (p && p.then) {
      p.then(() => {
        musicStarted = true;
        for (const ev of UNLOCK_EVENTS) window.removeEventListener(ev, tryPlayMusic, true);
      }).catch(() => { /* браузер ждёт жеста пользователя — повторим при следующем нажатии */ });
    }
  }
  // Браузеры блокируют автозапуск звука, поэтому музыка стартует при первом касании/клике/клавише.
  const UNLOCK_EVENTS = ["pointerdown", "pointerup", "touchend", "click", "keydown"];
  for (const ev of UNLOCK_EVENTS) window.addEventListener(ev, tryPlayMusic, true);

  /* ---------- ввод ---------- */

  canvas.addEventListener("pointerdown", (e) => {
    if (!game || (e.pointerType === "mouse" && e.button !== 0)) return;
    try { canvas.setPointerCapture(e.pointerId); } catch (_) { /* не критично */ }
    game.onPress(e.clientX, e.clientY);
    e.preventDefault();
  });
  canvas.addEventListener("pointermove", (e) => {
    if (!game || !(e.buttons & 1)) return;
    const events = e.getCoalescedEvents ? e.getCoalescedEvents() : [];
    if (events.length) for (const ce of events) game.onMove(ce.clientX, ce.clientY);
    else game.onMove(e.clientX, e.clientY);
  });
  const release = () => { if (game) game.onRelease(); };
  canvas.addEventListener("pointerup", release);
  canvas.addEventListener("pointercancel", release);
  canvas.addEventListener("contextmenu", (e) => e.preventDefault());
  window.addEventListener("keydown", (e) => { if (game) game.onKey(e); });
  window.addEventListener("resize", resize);

  /* ---------- запуск ---------- */

  function drawSplash(alpha) {
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, W, H);
    const im = images[SPLASH_IMAGE];
    if (!im || alpha <= 0) return;
    // на широком экране — «cover», на портретном — вписываем целиком, чтобы не обрезать логотип
    const fit = H > W ? Math.min : Math.max;
    const s = fit(W / im.naturalWidth, H / im.naturalHeight);
    const nw = im.naturalWidth * s, nh = im.naturalHeight * s;
    ctx.save();
    ctx.globalAlpha = Math.min(1, alpha);
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(im, (W - nw) / 2, (H - nh) / 2, nw, nh);
    ctx.restore();
  }

  const nextFrame = () => new Promise((res) => requestAnimationFrame(res));

  async function boot() {
    resize();
    tryPlayMusic();

    const fontReady = document.fonts && document.fonts.load
      ? document.fonts.load('20px "GRECHA"').catch(() => {})
      : Promise.resolve();
    await Promise.all([loadImage(SPLASH_IMAGE), fontReady]);
    const rest = Promise.all(IMAGE_FILES.map(loadImage));

    // заставка: 1 с полностью видна, затем 1 с плавно исчезает
    const t0 = performance.now();
    for (;;) {
      const elapsed = performance.now() - t0;
      if (elapsed >= 2000) break;
      drawSplash(elapsed < 1000 ? 1 : (2000 - elapsed) / 1000);
      await nextFrame();
    }

    let loaded = false;
    rest.then(() => { loaded = true; });
    while (!loaded) {
      drawSplash(0);
      setFont(ctx, 20, false);
      drawText(ctx, "Загрузка…", 20, false, "rgb(241,236,226)", W / 2, H / 2);
      await nextFrame();
    }

    game = new Game();
    let last = performance.now();
    function frame(now) {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      game.update(dt);
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      game.draw(ctx);
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }

  boot();
})();
