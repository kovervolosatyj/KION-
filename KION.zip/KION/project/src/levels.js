"use strict";
/* Логика уровней: перенос levels.py на JavaScript.
   Клетка кодируется числом r * K + c, поэтому соседи — это ±1 и ±K. */

const K = 100;
const cellId = (r, c) => r * K + c;
const cellRow = (id) => Math.floor(id / K);
const cellCol = (id) => id % K;

const ITEM_OWNER = { m: "B", h: "P", a: "R" };
const ITEM_NAME = { m: "mirror", h: "horse", a: "apple" };
const END_OWNER = { p: "P", r: "R", b: "B", g: "Y" };
const START_CHARS = "PRBY";

const TUTORIAL = [
  " Y  ",
  " ...",
  "....",
  "....",
  " g  ",
];

const L4 = [
  "...R ",
  ".....",
  " .. .",
  ".....",
  ".. ..",
  " ...r",
];

const SIMPLE = [
  TUTORIAL,
  [
    " PRB ",
    " ..m.",
    "h....",
    "...a.",
    "p.rb.",
  ],
  [
    " P.RB..",
    ".......",
    ".......",
    "  ....b",
    "  p..r ",
  ],
  [
    ".P  R.",
    "...  .",
    "p.....",
    " .....",
    "   r..",
  ],
  L4,
];

const NEIGH = [K, -K, 1, -1];

function parseLevel(rows) {
  const w = Math.max(...rows.map((r) => r.length));
  const tiles = new Set();
  const heroes = {};
  const items = new Map();
  const ends = {};
  rows.forEach((line, r) => {
    for (let c = 0; c < w; c++) {
      const ch = c < line.length ? line[c] : " ";
      if (ch === " ") continue;
      const id = cellId(r, c);
      tiles.add(id);
      if (START_CHARS.includes(ch)) {
        heroes[ch] = { id: ch, start: id, end: null, item: null, itemKind: null };
      } else if (ch in END_OWNER) {
        ends[END_OWNER[ch]] = id;
      } else if (ch in ITEM_OWNER) {
        items.set(id, [ITEM_OWNER[ch], ITEM_NAME[ch]]);
      }
    }
  });
  for (const hid in ends) heroes[hid].end = ends[hid];
  for (const [pos, [hid, kind]] of items) {
    heroes[hid].item = pos;
    heroes[hid].itemKind = kind;
  }
  const order = [...START_CHARS].filter((h) => heroes[h]);
  return { tiles, heroes: order.map((h) => heroes[h]), rows: rows.length, cols: w, items };
}

function adjacent(a, b) {
  const d = Math.abs(a - b);
  return d === 1 || d === K;
}

class Board {
  constructor(level) {
    this.level = level;
    this.reset();
  }

  reset() {
    this.paths = {};
    this.hero = {};
    for (const h of this.level.heroes) {
      this.paths[h.id] = [h.start];
      this.hero[h.id] = h;
    }
    this.active = null;
    this.started = false;
  }

  ownerOf(cell) {
    for (const hid in this.paths) {
      if (this.paths[hid].includes(cell)) return hid;
    }
    return null;
  }

  covered() {
    let n = 0;
    for (const hid in this.paths) n += this.paths[hid].length;
    return n;
  }

  heroDone(hid) {
    const p = this.paths[hid];
    return p[p.length - 1] === this.hero[hid].end;
  }

  itemCollected(hid) {
    const h = this.hero[hid];
    return h.item !== null && this.paths[hid].includes(h.item);
  }

  isComplete() {
    return this.covered() === this.level.tiles.size &&
      this.level.heroes.every((h) => this.heroDone(h.id));
  }

  canEnter(hid, cell) {
    if (!this.level.tiles.has(cell) || this.ownerOf(cell)) return false;
    for (const h of this.level.heroes) {
      if (h.id !== hid && h.end === cell) return false;
    }
    const it = this.level.items.get(cell);
    if (it && it[0] !== hid) return false;
    return true;
  }

  press(cell) {
    const hid = this.ownerOf(cell);
    if (hid === null) {
      this.active = null;
      return false;
    }
    const p = this.paths[hid];
    p.length = p.indexOf(cell) + 1;
    this.active = hid;
    this.started = true;
    return true;
  }

  release() {
    this.active = null;
  }

  /** Возвращает список событий: ["item"|"done"|"win", heroId|null] */
  step(cell) {
    const events = [];
    const hid = this.active;
    if (hid === null) return events;
    const p = this.paths[hid];
    if (cell === p[p.length - 1]) return events;
    if (p.includes(cell)) {
      p.length = p.indexOf(cell) + 1;
      return events;
    }
    if (!adjacent(p[p.length - 1], cell) || this.heroDone(hid)) return events;
    if (!this.canEnter(hid, cell)) return events;
    p.push(cell);
    const h = this.hero[hid];
    if (h.item !== null && cell === h.item) events.push(["item", hid]);
    if (this.heroDone(hid)) events.push(["done", hid]);
    if (this.isComplete()) events.push(["win", null]);
    return events;
  }
}

/** Поиск решения (используется для демонстрации пути в подсказках). */
function solve(level, limit = 200000) {
  const heroes = level.heroes;
  const occ = new Set(heroes.map((h) => h.start));
  const paths = {};
  heroes.forEach((h) => { paths[h.id] = [h.start]; });
  const ends = new Set(heroes.map((h) => h.end));
  const total = level.tiles.size;
  let budget = limit;

  const allowed = (h, cell) => {
    if (!level.tiles.has(cell) || occ.has(cell)) return false;
    if (ends.has(cell) && cell !== h.end) return false;
    const it = level.items.get(cell);
    return !(it && it[0] !== h.id);
  };

  const feasible = (idx) => {
    const free = [...level.tiles].filter((c) => !occ.has(c));
    const access = new Set();
    const cur = heroes[idx];
    const curPath = paths[cur.id];
    if (curPath[curPath.length - 1] !== cur.end) access.add(curPath[curPath.length - 1]);
    for (const h of heroes.slice(idx + 1)) access.add(h.start);
    const freeSet = new Set(free);
    for (const c of free) {
      let n = 0;
      for (const d of NEIGH) {
        const q = c + d;
        if (freeSet.has(q) || access.has(q)) n++;
      }
      if (n < (ends.has(c) ? 1 : 2)) return false;
    }
    const seen = new Set();
    for (const c of free) {
      if (seen.has(c)) continue;
      const st = [c];
      let touch = false;
      seen.add(c);
      while (st.length) {
        const x = st.pop();
        for (const d of NEIGH) {
          const q = x + d;
          if (access.has(q)) touch = true;
          if (freeSet.has(q) && !seen.has(q)) {
            seen.add(q);
            st.push(q);
          }
        }
      }
      if (!touch) return false;
    }
    return true;
  };

  const dfs = (idx) => {
    if (--budget < 0) return false;
    const h = heroes[idx];
    const p = paths[h.id];
    const head = p[p.length - 1];
    if (head === h.end) {
      if (idx === heroes.length - 1) return occ.size === total;
      return feasible(idx + 1) && dfs(idx + 1);
    }
    for (const d of NEIGH) {
      const q = head + d;
      if (allowed(h, q)) {
        occ.add(q);
        p.push(q);
        if (feasible(idx) && dfs(idx)) return true;
        occ.delete(q);
        p.pop();
      }
    }
    return false;
  };

  if (!dfs(0)) return null;
  const out = {};
  for (const hid in paths) out[hid] = paths[hid].slice();
  return out;
}

if (typeof module !== "undefined") {
  module.exports = { SIMPLE, parseLevel, Board, solve, cellId, cellRow, cellCol, K, adjacent };
}
